
public @interface BeforeSuite {

}
